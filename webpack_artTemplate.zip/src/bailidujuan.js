const data = require('@/option/json/bailidujuan.json')
const head = require('components/bailidujuan/publicTemplate/head.art.html')
const body = require('components/bailidujuan/publicTemplate/body.art.html')
const path = '../../src/' // 不可修改!
$('head').html(head({
  'root': path,
  'data': data
}))
